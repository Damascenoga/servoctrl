# Servo Control — compilação automática grátis pelo GitHub Actions

Projeto Android nativo (Kotlin) para controlar um servo SG90 ligado ao Arduino Uno via Bluetooth clássico HC-05.

## Como gerar o APK gratuitamente

1. Entre em https://github.com e crie uma conta ou entre na sua conta.
2. Clique no `+` no canto superior direito → **New repository**.
3. Dê um nome, por exemplo `ServoControlAndroid`. Pode ser **Public** ou **Private**. Clique em **Create repository**.
4. Na página do repositório, clique em **Add file** → **Upload files**.
5. Extraia este ZIP no computador e envie **todos os arquivos e pastas de dentro** para o repositório (incluindo a pasta oculta `.github`). Faça **Commit changes**.
   - Importante: não envie apenas o ZIP dentro do repositório. Envie o conteúdo extraído.
   - Se a interface web não mostrar a pasta `.github`, use GitHub Desktop ou faça upload via git; sem o workflow o build automático não será executado.
6. Abra a aba **Actions**. Se for solicitado, confirme que deseja habilitar workflows.
7. Selecione **Build Servo Control APK** e clique **Run workflow** (ou aguarde o build iniciar após o commit).
8. Abra a execução mais recente. Quando terminar com marca verde, vá até **Artifacts** e baixe `ServoControl-debug-apk`.
9. Extraia o ZIP do artifact baixado: dentro estará `app-debug.apk`. Transfira para seu Android e instale.

## O que está incluído

- Projeto Android Studio (Kotlin)
- Workflow GitHub Actions para compilar automaticamente o APK debug
- Código Arduino em `Arduino_Servo_HC05/Servo_HC05.ino`
- Controle de 0° a 180° e conexão Bluetooth clássico RFCOMM/SPP com dispositivos já pareados

## Ligações

- HC-05 TXD → Arduino D10 (RX do SoftwareSerial)
- Arduino D11 (TX do SoftwareSerial) → HC-05 RXD por divisor de tensão
- HC-05 VCC → 5V, GND → GND
- Sinal SG90 → D9
- Alimente o servo com 5V regulado adequado; una o GND da fonte ao GND do Arduino.

## Observações

- O workflow usa GitHub Actions e publica um APK debug como artifact; não publica automaticamente um APK na Google Play.
- APK debug é apropriado para testes pessoais; não é uma versão de lançamento assinada para distribuição ampla.
- A primeira compilação pode falhar se houver alterações futuras nos serviços de build/dependências; verifique o log na aba Actions se isso ocorrer.
- Pareie o HC-05 primeiro nas configurações Bluetooth do Android (PIN comum 1234 ou 0000).
