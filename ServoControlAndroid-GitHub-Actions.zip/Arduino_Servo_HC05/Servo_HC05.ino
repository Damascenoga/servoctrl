#include <SoftwareSerial.h>
#include <Servo.h>

// Arduino RX, TX. HC-05 TXD -> D10; Arduino D11 -> HC-05 RXD
SoftwareSerial bluetooth(10, 11);
Servo servo;

const byte SERVO_PIN = 9;
String received = "";

void setup() {
  Serial.begin(9600);
  bluetooth.begin(9600); // padrão comum do HC-05 em modo de dados
  servo.attach(SERVO_PIN);
  servo.write(90);
  Serial.println("Servo pronto. Envie um angulo de 0 a 180.");
}

void loop() {
  while (bluetooth.available()) {
    char c = (char)bluetooth.read();

    if (c == '\n' || c == '\r') {
      if (received.length() > 0) {
        int angle = received.toInt();
        angle = constrain(angle, 0, 180);
        servo.write(angle);
        Serial.print("Angulo recebido: ");
        Serial.println(angle);
        received = "";
      }
    } else if (isDigit(c) && received.length() < 3) {
      received += c;
    } else if (c == '\b') {
      received = "";
    }
  }
}
