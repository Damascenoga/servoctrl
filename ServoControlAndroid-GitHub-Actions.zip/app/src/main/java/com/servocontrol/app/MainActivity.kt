package com.servocontrol.app

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val requestBluetoothPermission = 100
    private var adapter: BluetoothAdapter? = null
    private var socket: BluetoothSocket? = null
    private var output: OutputStream? = null
    private lateinit var status: TextView
    private lateinit var deviceSpinner: Spinner
    private lateinit var angleText: TextView
    private lateinit var seek: SeekBar
    private lateinit var connectButton: Button
    private var selectedAngle = 90
    private var devices: List<BluetoothDevice> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = BluetoothAdapter.getDefaultAdapter()
        buildUi()
        if (adapter == null) {
            status.text = "Este celular não possui Bluetooth clássico."
            connectButton.isEnabled = false
        } else if (hasConnectPermission()) {
            loadPairedDevices()
        } else {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), requestBluetoothPermission)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 24)
        }
        root.addView(TextView(this).apply {
            text = "SERVO CONTROL"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(0xFF1769AA.toInt())
        }, matchWidth())
        root.addView(TextView(this).apply {
            text = "Arduino Uno • SG90 • HC-05"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 22)
        }, matchWidth())

        status = TextView(this).apply {
            text = "Status: desconectado"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 12)
        }
        root.addView(status, matchWidth())

        root.addView(TextView(this).apply {
            text = "Dispositivo Bluetooth pareado"
            textSize = 15f
        }, matchWidth())
        deviceSpinner = Spinner(this)
        root.addView(deviceSpinner, matchWidth())

        connectButton = Button(this).apply {
            text = "CONECTAR AO HC-05"
            setOnClickListener { connectSelected() }
        }
        root.addView(connectButton, matchWidth())

        angleText = TextView(this).apply {
            text = "90°"
            textSize = 48f
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 8)
        }
        root.addView(angleText, matchWidth())

        seek = SeekBar(this).apply {
            max = 180
            progress = 90
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    selectedAngle = progress
                    angleText.text = "$progress°"
                    if (fromUser) sendAngle(progress)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) { sendAngle(selectedAngle) }
            })
        }
        root.addView(seek, matchWidth())

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(0, 45, 90, 135, 180).forEach { angle ->
            buttons.addView(Button(this).apply {
                text = "$angle°"
                setOnClickListener {
                    seek.progress = angle
                    sendAngle(angle)
                }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(buttons, matchWidth())

        root.addView(Button(this).apply {
            text = "DESCONECTAR"
            setOnClickListener { disconnect() }
        }, matchWidth())

        root.addView(TextView(this).apply {
            text = "Pareie o HC-05 nas configurações do Android antes de conectar. PIN comum: 1234 ou 0000."
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 0)
        }, matchWidth())

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun hasConnectPermission(): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun loadPairedDevices() {
        if (!hasConnectPermission()) return
        try {
            devices = adapter?.bondedDevices?.sortedBy { it.name ?: it.address }?.toList() ?: emptyList()
            val labels = devices.map { "${it.name ?: "Dispositivo"} — ${it.address}" }
            deviceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
            if (devices.isEmpty()) status.text = "Nenhum dispositivo pareado. Pareie o HC-05 nas configurações do Android."
        } catch (_: SecurityException) {
            status.text = "Permissão Bluetooth necessária."
        }
    }

    private fun connectSelected() {
        if (!hasConnectPermission()) {
            if (Build.VERSION.SDK_INT >= 31) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), requestBluetoothPermission)
            return
        }
        if (devices.isEmpty()) {
            loadPairedDevices()
            Toast.makeText(this, "Pareie o HC-05 nas configurações do Android primeiro.", Toast.LENGTH_LONG).show()
            return
        }
        val device = devices.getOrNull(deviceSpinner.selectedItemPosition) ?: return
        status.text = "Conectando a ${device.name ?: "HC-05"}..."
        connectButton.isEnabled = false
        thread {
            try {
                adapter?.cancelDiscovery()
                val newSocket = device.createRfcommSocketToServiceRecord(sppUuid)
                newSocket.connect()
                socket = newSocket
                output = newSocket.outputStream
                runOnUiThread {
                    status.text = "Conectado: ${device.name ?: "HC-05"}"
                    connectButton.isEnabled = true
                    sendAngle(selectedAngle)
                }
            } catch (e: Exception) {
                try { socket?.close() } catch (_: Exception) {}
                socket = null
                output = null
                runOnUiThread {
                    status.text = "Falha ao conectar. Confira pareamento e alimentação."
                    connectButton.isEnabled = true
                    Toast.makeText(this, e.message ?: "Erro Bluetooth", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun sendAngle(angle: Int) {
        val safeAngle = angle.coerceIn(0, 180)
        try {
            output?.write("$safeAngle\n".toByteArray(Charsets.US_ASCII))
            output?.flush()
        } catch (_: Exception) {
            status.text = "Sem conexão Bluetooth"
        }
    }

    private fun disconnect() {
        try { output?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        output = null
        socket = null
        status.text = "Status: desconectado"
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestBluetoothPermission) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) loadPairedDevices()
            else status.text = "Permissão Bluetooth negada."
        }
    }

    override fun onDestroy() {
        disconnect()
        super.onDestroy()
    }
}
